import java.util.Scanner;

public class static2 {

    static int n;  
    int m;          

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        static2 M = new static2();

         int n;              
        M.m = s.nextInt();  

       System.out.println(n);
        System.out.println(M.m);
    }
}
